import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import jwt from 'jsonwebtoken';

export function middleware(request: NextRequest) {
  const token = request.cookies.get('token')?.value; // Obtiene el token de las cookies

  // Si no existe el token, redirige al login
  if (!token) {
    return NextResponse.redirect(new URL('/login', request.url));
  }

  try {
    // Verifica el token usando la clave secreta
    const decodedToken = jwt.verify(token, process.env.JWT_SECRET_KEY!) as jwt.JwtPayload & { role?: string };
    console.log('Token decodificado 4:', decodedToken);
    
    // Permitir acceso según el rol
    if (decodedToken.role === 'admin' && request.nextUrl.pathname.startsWith('/admin')) {
      return NextResponse.next(); // Permite acceso a la ruta de admin
    } else if (decodedToken.role === 'user' && request.nextUrl.pathname.startsWith('/user')) {
      return NextResponse.next(); // Permite acceso a la ruta de usuario
    } else {
      return NextResponse.redirect(new URL('/login', request.url)); // Redirige si no coincide el rol
    }
  } catch (error) {
    // Si hay un error en la verificación del token, redirige al login
    return NextResponse.redirect(new URL('/userDashboard', request.url));
  }
}

export const config = {
  matcher: ['/userDashboard/:path*', '/adminDashboard/:path*'], // Rutas que deben estar protegidas
};
